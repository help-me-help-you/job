<div class="notice notice-warning is-dismissible">
	<p><?php echo esc_html__( 'Listing Manager requires WooCoomerce to be installed.', 'listing-manager' ); ?></p>
</div>	