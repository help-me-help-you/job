<div class="woocommerce-message">
    <?php echo esc_html__( 'Object does not exist.', 'listing-manager' ); ?>
</div><!-- /.woocommerce-message -->
