<input type="hidden" id="<?php echo esc_attr( $id ); ?>" name="<?php echo esc_attr( $id ); ?>" value="<?php if ( ! empty( $value ) ) : ?><?php echo esc_html( $value ); ?><?php endif; ?>">
