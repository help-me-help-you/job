<div class="wrap">
	<h1><?php echo esc_html__( 'Front Fields Builder', 'listing-manager' ); ?></h1>

	<div id="field-builder" 
		 data-source="<?php echo admin_url( 'admin-ajax.php' ); ?>"></div>
</div><!-- /.wrap -->
